import UIKit

var greeting = "Hello, playground"

print(greeting)

var a=1
var b=1

a=2
print(a+b)
print(a-b)
print(a*b)
print(a/b)

